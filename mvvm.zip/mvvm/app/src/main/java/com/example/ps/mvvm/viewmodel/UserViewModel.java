package com.example.ps.mvvm.viewmodel;

import android.content.Context;
import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.databinding.library.baseAdapters.BR;
import androidx.lifecycle.MutableLiveData;

import com.example.ps.mvvm.model.User;

public class UserViewModel extends BaseObservable {

    MutableLiveData<String> mutableLiveData = new MutableLiveData<>();

    private String name;
    private String phone;
    private Context context;

    public UserViewModel(User user) {
        this.name = user.getName();
        this.phone = user.getPhone();
    }

    public UserViewModel(Context context) {
        this.context = context;
    }

    @Bindable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        notifyPropertyChanged(BR.name);
//        mutableLiveData.postValue(name);
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

//    public MutableLiveData<String> getMutableLiveData() {
//        return mutableLiveData;
//    }
}
